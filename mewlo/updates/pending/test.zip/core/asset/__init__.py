# package
"""
This package is the root directory for "core" mewlo "mpackages", which essentially covers ALL official key mewlo code, organized into a hierarchy of modules and packages.
"""