"""
webhelp.py
This module contains misclenaeous helper functions related to online web functions
"""


# helper imports
from ..eventlog import mevent
from ..eventlog import mexceptionplus
from misc import readfile_asjson

# python imports
import requests





def download(url):
    """Download a file from a url, return the file."""
    r = requests.get(url)
    return r


def download_file_asstring(url):
    """Download a file from a url, return as string."""
    r = download(url)
    return r.text


def download_file_as_jsondict(url):
    """Download a file from a url, return it as a parsed json dictionary."""
    r = download(url)
    print "ATTN: DEBUG downloaded {0} as: ".format(url) + str(r)
    rjson = r.json()
    return rjson



