"""
mpackage.py
Works with packagemanager.py to support our package/extension/addon system
"""


# mewlo imports
from ..helpers.misc import readfile_asjson, compare_versionstrings_isremotenewer
from ..eventlog.mevent import EventList, EFailure, EWarning
from ..eventlog.mexceptionplus import ExceptionPlus
from ..helpers.webhelp import download_file_as_jsondict

# python imports
import json
import os




class MewloPackage(object):
    """
    The MewloPackage class represents a mewlo "package" aka extension/plugin/addon/component.
    It is *not* the same as a Python "package".
    All code (both core builtin code and 3rd party extensions/plugins) is always represented/supervised/versioned by one and only one mewlo package.
    The MewloPackage class exposes author and version info about a package, supports online, version checking, database updating, dependency chains, etc.

    It is actually a fairly light-weight structure that:
        * loads a json info file with information about the "addon package".
        * dynamically loads(imports) a python code module specified by the json info file.
        * dynamically instantiates a PackageObject object from the above python code module.
    It is actually the PackageObject object that, once instantiated, does the work of the addon.
    So, the right way to think of a Package is as the bridge middleman responsible for instantiating a PackageObject addon.
    One reason we use this middleman object is so that we can instantiate (just) the middleman wrapper around the json info file, even when the addon is DISABLED.
    In this way, we can have instantiated MewloPackage objects even for missing/disabled MewloPackageObjects.
    Additional features that the Package class provides:
        * displaying addon info, version info, update checking, etc.
        * handles dependency checking, etc.
    A MewloPackage also keeps an eventlist of any warnings or errors encountered while trying to instantiate the PackageObject.
    If an addon cannot be located/loaded/etc., the error information will be stored in this eventlist, and the addon will be disabled.
    """

    # class constants
    DEF_INFOFIELD_isrequired = 'isrequired'
    DEF_INFOFIELD_requires = 'requires'
    DEF_INFOFIELD_uniqueid = 'uniqueid'
    DEF_INFOFIELD_requiredpackages = 'packages'
    DEF_INFOFIELD_codefile = 'codefile'
    DEF_INFOFIELD_codeclass = 'codeclass'
    DEF_INFOFIELD_url_version = 'url.version'
    DEF_INFOFIELD_version = 'version'
    DEF_INFOFIELD_versiondate = 'versiondate'


    def __init__(self, packagemanager, filepath):
        # keep pointer to package manager
        self.packagemanager = packagemanager
        # found info (json) file defining the package
        self.infofilepath = filepath
        # dictionary acquired from info file
        self.infodict = None
        # imported module of code
        self.codemodule_path = ''
        self.codemodule = None
        self.packageobject = None
        #
        self.readytoloadcode = False
        self.readytorun = False
        self.enabled = False
        self.enabledisablereason = "n/a"
        #
        self.eventlist = EventList()


    def get_uniqueid(self):
        return self.get_ourinfofile_property(MewloPackage.DEF_INFOFIELD_uniqueid,'[uniqueid_not_specified]')

    def get_infofilepath(self):
        return self.infofilepath

    def do_enabledisable(self, mewlosite, flag_enable, reason, eventlist):
        """
        Set the disabled flag for the package.  If False than the code for the package will not be loaded and run.
        return None on success, or failure on error.
        """
        retv = None
        alreadyenabled = self.enabled

        # do stuff on change of state
        if (alreadyenabled == flag_enable):
            # nothing to do, it's already where we want it
            pass
        elif (flag_enable):
            # we want to enable this package that is currently not enabled
            # ATTN: todo - do we want to OVERRIDE/IGNORE any settings that say to disable this package when we are told to explicitly enable it? I say yes.
            retv = self.startup(mewlosite, eventlist)
        elif (not flag_enable):
            # we want to disable this package that is currently enabled
            retv = self.shutdown()
        # change state on absence of error
        if (retv==None):
            self.enabled = flag_enable
            self.enabledisablereason = reason
        # return
        return retv



    def create_packageobject(self, packageobj_class):
        """Create an appropriate child package; subclasses will reimplement this to use their preferred child class."""
        obj = packageobj_class(self)
        return obj



    def load_infofile(self):
        """Load the info file (json data) for this package."""

        # init
        self.infodict = None
        self.readytoloadcode = False

        # read the json file and parse it into a dictionary
        self.infodict, failure = readfile_asjson(self.infofilepath, "Package info file")
        if (failure == None):
            # set readytoloadcode true since the json parsed properly
            self.readytoloadcode = True
        else:
            # failed; add the error message to our eventlist, and continue with this package marked as not useable
            self.eventlist.add(failure)
            # we could raise an exception immediately if we wanted from the failure
            if (True):
                raise ExceptionPlus(failure)



    def load_codemodule(self):
        """
        Import the codemodule associated with this package.
        Return None on success or failure on error
        """

        # init
        self.codemodule = None
        self.codemodule_path = ''
        self.packageobject = None
        self.readytorun = False

        # get path to code module
        self.codemodule_path, failure = self.get_pathtocodemodule()
        if (failure == None):
            # ask package manager to load the import from the path
            self.codemodule, failure = self.packagemanager.loadimport(self.codemodule_path)

        if (failure == None):
            # if the import worked, instantiate the package object from it
            failure = self.instantiate_packageobject()

        if (failure == None):
            # success so mark it as ready to run
            self.readytorun = True
        else:
            # failed; add the error message to our eventlist, and continue with this package marked as not useable? or raise exception right away
            self.eventlist.add(failure)
            if (True):
                raise ExceptionPlus(failure)
        # return failure
        return failure


    def get_pathtocodemodule(self):
        """The info file for the package should tell us what module file to import; we default to same name as info file but with .py"""

        # default module name
        path = self.infofilepath
        dir, fullname = os.path.split(path)
        name, ext = os.path.splitext(fullname)
        pathtocodemodule_default = name + '.py'
        # override with explicit
        pathtocodemodule = dir + '/' + self.get_ourinfofile_property(MewloPackage.DEF_INFOFIELD_codefile, pathtocodemodule_default)
        # return it
        return pathtocodemodule, None



    def instantiate_packageobject(self):
        """Assuming we have imported the dynamic package module, now create the package object that we invoke to do work"""

        # init
        self.packageobject = None

        # module loaded in memory?
        if (self.codemodule == None):
            return EFailure("No code module imported to instantiate package object from.")

        # object class defined in info dictionary?
        packageobject_classname = self.get_ourinfofile_property(MewloPackage.DEF_INFOFIELD_codeclass, None)
        if (packageobject_classname == None):
            return EFailure("Package info file is missing the 'codeclass' property which defines the class of the MewloPackage derived class in the package module.")

        # does it exist
        if (not packageobject_classname in dir(self.codemodule)):
            return EFailure("Package class '{0}' not found in package module '{1}'.".format(packageobject_classname, self.codemodule.__name__))

        # instantiate it
        try:
            packageobj_class = getattr(self.codemodule, packageobject_classname)
            packageobj = self.create_packageobject(packageobj_class)
        except:
            return EFailure("Package class object '{0}' was found in package module, but could not be instantiated.".format(packageobject_classname))

        # always prepare it first
        failure = packageobj.prepare(self.packagemanager.mewlosite.packagesettings)
        if (failure != None):
            # failure to prepare, so we let it go and return the failure
            packageobj = None
            return failure

        # save it for use
        self.packageobject = packageobj
        # no failure returns None
        return None



    def get_ourinfofile_property(self, propertyname, defaultval=None):
        """Lookup property in our info dict and return it, or defaultval if not found."""
        return self.get_aninfofile_property(self.infodict,propertyname,defaultval)

    def get_aninfofile_property(self, infodict, propertyname, defaultval=None):
        """Lookup property in an info dict and return it, or defaultval if not found."""

        if (infodict == None):
            return defaultval
        if (propertyname in infodict):
            return infodict[propertyname]
        return defaultval



    def startup(self, mewlosite, eventlist):
        """Do any startup stuff."""
        if (self.readytoloadcode):
            # load the code module
            failure = self.load_codemodule()
            if (failure!=None):
                return failure
            if (self.packageobject!=None):
                # now start it up
                failure = self.packageobject.checkusable()
                if (failure!=None):
                    return failure
                failure = self.packageobject.startup(mewlosite, eventlist)
                return failure
        # ATTN: do we want to throw an error/failure in this case where the code module is not ready to run?


    def shutdown(self):
        """Do any shutdown stuff."""
        if (self.packageobject!=None):
            self.packageobject.shutdown()
            # and now release the packageobject payload to garbage collection
            self.packageobject = None

    def get_mewlosite(self):
        return self.packagemanager.get_mewlosite()














    def dumps(self, indent=0):
        """Return a string (with newlines and indents) that displays some debugging useful information about the object."""

        outstr = " "*indent + "Package '{0}' reporting in:\n".format(self.get_uniqueid())
        indent += 1
        #
        outstr += self.eventlist.dumps(indent)
        #
        outstr += " "*indent + "Enabled: " + str(self.enabled) + " ("+self.enabledisablereason+").\n"
        #
        outstr += " "*indent + "Info dictionary: " + self.get_infofilepath() + ":\n"
        jsonstring = json.dumps(self.infodict, indent=indent+1)
        outstr += " "*indent + " '" + jsonstring + "'\n"
        #
        outstr += " "*indent + "Code module file: " + self.codemodule_path + "\n"
        #
        outstr += " "*indent + "Code module: "
        outstr += str(self.codemodule) + "\n"
        #
        outstr += " "*indent + "Package object: "
        outstr += str(self.packageobject) + "\n"
        if (self.packageobject):
            outstr += self.packageobject.dumps(indent+1)
        #
        return outstr
















    def updatemessage(self, msg):
        """Return a warning with info about package id."""
        msg = "Package '{0}' with info file '{1}': ".format(self.get_uniqueid(), self.get_infofilepath()) + msg
        return msg

    def updatewarning(self, msg):
        """Return a warning with info about package id."""
        msg = self.updatemessage(msg)
        return EWarning(msg)




    def updatecheck(self, eventlist):
        """
        Check package for updates.
        Note this covers not just web updates available, but database updates needed.
        Division of labor:
            We (the MewloPackage wrapper) can do a web check
            but we have to ask the MewloPackageObject to do the database check.
        """
        failure = self.updatecheck_checkfornewfiles(eventlist)
        if (self.packageobject!=None):
            failure = self.packageobject.updatecheck_checkdatabase(eventlist)




    def updatecheck_checkfornewfiles(self, eventlist):
        """
        Check web for new files available, and check our download staging directory for these?
        The different components here are:
            1. web check at url specified in our info file for an online version check
            2. web check at some central repository based on uniqueid
            3. check in local "to-install" folder
            4. identification of the file to download
        ATTN: unfinished
        """
        # download web version info json file and parse it
        webinfodict = self.download_versioninfodict(eventlist)
        localversion = self.get_ourinfofile_property(MewloPackage.DEF_INFOFIELD_version, None)
        remoteversion = self.get_aninfofile_property(webinfodict, MewloPackage.DEF_INFOFIELD_version, None)
        if (remoteversion==None):
            # error, no remote version info
            return None
        isneweravail = compare_versionstrings_isremotenewer(localversion, remoteversion)
        if (not isneweravail):
            return None
        remotedate  = self.get_aninfofile_property(webinfodict, MewloPackage.DEF_INFOFIELD_versiondate, 'undated')
        eventlist.append(self.updatewarning("Newer version ({0} - {1}) is available online.".format(remoteversion,remotedate)))
        return None




    def download_versioninfodict(self, eventlist):
        """
        Download and parse web info file
        """
        versionfile_url = self.get_ourinfofile_property(MewloPackage.DEF_INFOFIELD_url_version, None)
        if (versionfile_url == None):
            eventlist.append(self.updatewarning("No url to check online for updates specified ('url.version')."))
            return None
        webinfodict = download_file_as_jsondict(versionfile_url)
        #print "ATTN: downloaded webinfo dict from {0} as:".format(versionfile_url) + str(webinfodict)
        return webinfodict








