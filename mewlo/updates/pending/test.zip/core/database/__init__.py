# package
"""
This package collects modules that are used by Mewlo but do not have any dependencies on, or references to, mewlo code.
"""