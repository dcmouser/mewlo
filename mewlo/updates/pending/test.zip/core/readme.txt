Core required foundational mewlo packages go here.

These packages are shared among ALL mewlo sites.